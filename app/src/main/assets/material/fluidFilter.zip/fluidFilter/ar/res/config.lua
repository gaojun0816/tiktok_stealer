local config = {}

config.defaultTime = 6.0
config.maxTime = 8.0
config.minTime = 1.5
config.fps = 24
config.zoom = 2.5

return config